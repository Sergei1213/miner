from typing import Iterable
from bs4 import BeautifulSoup
import requests
import json
from datetime import datetime
import time

def get_firs_news():
    headers = {
        "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36"
    }

    url = "https://habr.com/ru/flows/admin/"
    
    r = requests.get(url=url, headers=headers)

    soup = BeautifulSoup(r.text, "lxml")

    article_cards = soup.find_all("article", class_="tm-articles-list__item")
    
    new_dict={}
    for article in article_cards:
        article_title = article.find("a", class_="tm-article-snippet__title-link").text
        article_title_str = str(article_title)
        article_url = article.find("a", class_="tm-article-snippet__title-link").get("href")
        article_norm_url= f'https://habr.com{article_url}'
        article_time = article.find("time").get("datetime")[:-5]
        date_time= datetime.strptime(article_time, "%Y-%m-%dT%H:%M:%S")
        time = date_time.strftime('%Y-%m-%dT%H:%M:%S')
        time_split = time.split("T")
        time_join = ' '.join(time_split)
        article_id = article.get("id")
        

        # print(f"{article_title}| {date_time}| {article_norm_url} | {article_id}") 
        # print(f'{article_title_str}')
        new_dict[article_id]={
            "article_title_str": article_title_str,
            "article_url": article_norm_url,
            "time_join": time_join
        }
    
    
    # print(new_dict)

    with open("news_dict.json", "w") as file:
        json.dump(new_dict, file, indent=4, ensure_ascii=False)


def get_new_news():
    with open("news_dict.json") as file:
        new_list = json.load(file)

    headers = {
        "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36"
    }

    url = "https://habr.com/ru/flows/admin/"
    
    r = requests.get(url=url, headers=headers)

    soup = BeautifulSoup(r.text, "lxml")

    article_cards = soup.find_all("article", class_="tm-articles-list__item")
    
    fresh_news={}
    for article in article_cards:
        article_id = article.get("id")

        if article_id in new_list:
            continue
        else:
            article_title = article.find("a", class_="tm-article-snippet__title-link").text
            article_title_str = str(article_title)
            article_url = article.find("a", class_="tm-article-snippet__title-link").get("href")
            article_norm_url= f'https://habr.com{article_url}'
            article_time = article.find("time").get("datetime")[:-5]
            date_time= datetime.strptime(article_time, "%Y-%m-%dT%H:%M:%S")
            time = date_time.strftime('%Y-%m-%dT%H:%M:%S')
            time_split = time.split("T")
            time_join = ' '.join(time_split)
            article_id = article.get("id")
            
            new_list[article_id]={
                "article_title_str": article_title_str,
                "article_url": article_norm_url,
                "time_join": time_join
            }
        
            fresh_news[article_id]={
                "article_title_str": article_title_str,
                "article_url": article_norm_url,
                "time_join": time_join
            }
        
    with open("news_dict.json", "w") as file:
        json.dump(new_list, file, indent=4, ensure_ascii=False)


    return fresh_news
    
def main():
    # get_firs_news()
    get_new_news()


if __name__ == "__main__":
    main()