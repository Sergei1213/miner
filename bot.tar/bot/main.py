from aiogram import Bot, Dispatcher, executor, types
import json
from aiogram.utils.markdown import hcode, hlink
from aiogram.dispatcher.filters import Text
from pars import get_new_news
bot=Bot(token = "5060630211:AAHgE7yx2anG77WqqvCRH5rMYu606RjXehY", parse_mode=types.ParseMode.HTML);
dp = Dispatcher(bot)

@dp.message_handler(commands="start")
async def start(message: types.Message):
    start_buttons = ["Всі новини","Останні 5 новин", "Свіжі новини"]
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(*start_buttons)
    await message.answer("Новини", reply_markup=keyboard)

@dp.message_handler(Text(equals="Всі новини"))
async def all_news(message: types.Message):
    with open("news_dict.json") as file:
        new_dict = json.load(file)

    for k, v in sorted(new_dict.items()):
        news = f"{hcode(v['time_join'])}\n{hlink(v['article_title_str'], v['article_url'])}"


        await message.answer(news)

@dp.message_handler(Text(equals="Останні 5 новин"))
async def take_5_news(message: types.Message):
    with open("news_dict.json") as file:
        new_dict = json.load(file)

    for k, v in sorted(new_dict.items())[-5:]:
        news = f"{hcode(v['time_join'])}\n{hlink(v['article_title_str'], v['article_url'])}"

        
        await message.answer(news)

@dp.message_handler(Text(equals="Свіжі новини"))
async def take_fresh_news(message: types.Message):
    fresh_news = get_new_news()

    if len(fresh_news) >= 1:
        for k, v in sorted(fresh_news.items()):
            news = f"{hcode(v['time_join'])}\n{hlink(v['article_title_str'], v['article_url'])}"

        
            await message.answer(news)
    else:
        await message.answer("Очікування нових новин....")
if __name__ == '__main__':
    executor.start_polling(dp)