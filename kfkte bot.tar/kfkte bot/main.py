from config import token
import telebot
from pars import pars


token=token
bot = telebot.TeleBot(token)

@bot.message_handler(commands=['start'])
def start_message(message):
  bot.send_message(message.chat.id,"Привет ✌️ ")

@bot.message_handler(content_types=('text'))
def message_reply(message):
    if message.text == "Заміни" :
        pars()
        photo = open('img.jpg', 'rb')
        bot.send_photo(message.chat.id, photo)




if __name__ == '__main__':
    bot.infinity_polling()      

