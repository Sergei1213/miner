import urllib.request

def pars():
    url = "http://ccte.nau.edu.ua/images/Zameni.jpg"
    img = urllib.request.urlopen(url).read()
    out = open("img.jpg", "wb")
    out.write(img)
    out.close()
    

if __name__ == "__main__":
    pars()


